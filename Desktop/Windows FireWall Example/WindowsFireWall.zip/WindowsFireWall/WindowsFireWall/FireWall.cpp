#include "FireWall.h"

HRESULT FireWall_Initialize(INetFwPolicy2* pNetFwPolicy2) {
	HRESULT hr = S_OK;

	hr = CoCreateInstance(_uuidof(NetFwPolicy2), NULL, CLSCTX_INPROC_SERVER, __uuidof(NetFwPolicy2), (void**)pNetFwPolicy2);
	
	if (FAILED(hr))
	{
		cout << "Initialize NetFwPolicy Failed" << endl;
		goto Clear;
	}

Clear: {
	return hr;
	}
}

bool Firewall_Add_Application(const wchar_t* cwName, const wchar_t* cwFilePath,
	const wchar_t*cwDescription, const wchar_t*cwGroup,
	NET_FW_RULE_DIRECTION nfDirection, NET_FW_PROFILE_TYPE2_ nfProfileType,
	NET_FW_IP_PROTOCOL_ nfProtocol, NET_FW_ACTION_ nfAction) {
	
}

bool FireWall_IsEnable() {

	HRESULT CreateInstance = S_OK;
	HRESULT Colnitialize = E_FAIL;

	VARIANT_BOOL fwEnable;

	INetFwMgr* fwMgr = NULL;
	INetFwPolicy* fwPolicy = NULL;
	INetFwProfile* fwProfile = NULL;
	
	_ASSERT(fwProfile != NULL);

	fwProfile = NULL;

	CoInitialize = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
		if (CoInitialize != RPC_E_CHANGED_MODE)
			if (FAILED(CoInitialize)){
				cont << "Initialize Failed" << endl;
				goto Clear;
			}
		
		CreateInstance = CoCreateInstance
		

}
bool FireWall_TurnOn() {

}
bool FireWall_TurnOff() {

}
